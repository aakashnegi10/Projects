from flask import Flask, jsonify, request
from flask_restful import Resource, Api,reqparse
from transformers import pipeline
from logging import debug

# creating the flask app

# bart_summarizer= pipeline('summarization',model='lidiya/bart-large-xsum-samsum')
# print('bart success')
t5_summarizer=pipeline('summarization',model='anegi/t5smallmodel')
print('t5 success')

app=Flask(__name__)
api=Api(app)

parser=reqparse.RequestParser()
parser.add_argument('inputText',action='append',required=True)


class TextSummarization(Resource):
    def get(self):
        
        args=parser.parse_args()

        # bart_summary=bart_summarizer(args['inputText'])
        
        t5_summary=t5_summarizer(args['inputText'])

        return jsonify({'t5_summary':t5_summary[0]['summary_text']})


api.add_resource(TextSummarization,"/summarize")

if __name__=="__main__":
    app.run()