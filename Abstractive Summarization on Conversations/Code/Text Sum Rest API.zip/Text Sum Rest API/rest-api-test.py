import requests

url='http://127.0.0.1:5000/summarize'


data={'inputText':"""
Sam: Oh? Bob!

Bob: Hey Sam! Good to see you!

Sam: How’s it going?

Bob: Yeah, good. Working a lot. And you?

Sam: I went back to school.

Bob: Good for you!

Mike and Jim

Jim: Mike?

Mike: Jim?

Jim: What have you been up to?

Mike: Working a lot.

Jim: That sounds hard.

Mike: How’s the family?

Jim: Everyone is good. Thanks! 
"""}

summaries=requests.get(url,json=data)

print(summaries.json())